class Gem::Commands::CrashCommand < Gem::Command

  raise "crash"

end
